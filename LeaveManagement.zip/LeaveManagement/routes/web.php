<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/home', function(){
    return redirect(auth()->user()->role == "Manager" ? "/leave-requests" : "dashboard");
});

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [App\Http\Controllers\LeaveDashboardController::class, 'index']);

    Route::resource('leave-requests', App\Http\Controllers\LeaveRequestController::class);
    Route::get('report', [App\Http\Controllers\LeaveRequestController::class, 'report']);
});
