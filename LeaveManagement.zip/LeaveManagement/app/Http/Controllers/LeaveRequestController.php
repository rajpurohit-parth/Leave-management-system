<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\LeaveRequest;
use App\Models\LeaveBalance;
use Illuminate\Http\Request;
use App\Http\Requests\ApplyLeaveRequest;

class LeaveRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $user = auth()->user();

        if($user->role != 'Manager'){
            abort(403);
        }

        $requests = LeaveRequest::with('user')->get();

        return view('leave.index', compact('requests'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ApplyLeaveRequest $request)
    {

        $user = auth()->user();

        $overlap = LeaveRequest::where('user_id', $user->id)->where(function($q) use ($request) {
            $q->whereBetween('start_date', [$request->start_date, $request->end_date])
                ->orWhereBetween('end_date', [$request->start_date, $request->end_date]);
        })->exists();

        if($overlap){
            return redirect()->back()->with('error', 'Overlapping leave request exists.');
        }

        $days = Carbon::parse($request->start_date)->diffInDays($request->end_date) + 1;
        $balance = LeaveBalance::where(['user_id' => $user->id, 'leave_type' => $request->leave_type])->first();

        if(!$balance || $balance->balance < $days){
            return redirect()->back()->with('error', 'Insufficiant leave balance.');
        }

        LeaveRequest::create([
            'user_id' => $user->id,
            'leave_type' => $request->leave_type,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'reason' => $request->reason,
        ]);

        return redirect()->back()->with('success', 'Leave request submitted.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $user = auth()->user();

        if($user->role != 'Manager'){
            abort(403);
        }

        $leaveRequest = LeaveRequest::find($id);

        if($request->status == "Approved"){
            $days = Carbon::parse($leaveRequest->start_date)->diffInDays($leaveRequest->end_date) + 1;
            $balance = LeaveBalance::where(['user_id' => $leaveRequest->user_id, 'leave_type' => $leaveRequest->leave_type])->first();

            if(!$balance || $balance->balance < $days){
                return redirect()->back()->with('error', 'Insufficiant leave balance. Cannot approve.');
            }

            $leaveRequest->update(['status' => "Approved"]);
            $balance->decrement('balance', $days);
        }else{
            $leaveRequest->update(['status' => $request->status]);
        }

        return redirect()->back()->with('success', 'Leave request '. $request->status.' successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     *
     */
    public function report(Request $request){
        $query = LeaveRequest::query();

        if(!empty($request->leave_type)){
            $query->where('leave_type', $request->leave_type);
        }

        if(!empty($request->from) && !empty($request->from)){
            $query->whereBetween('start_date', [$request->start_date, $request->end_date]);
        }

        $report = $query->with('user')->get();

        return view('leave.report', compact('report'));
    }
}
