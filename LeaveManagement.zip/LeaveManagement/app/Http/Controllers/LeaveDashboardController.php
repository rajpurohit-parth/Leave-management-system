<?php

namespace App\Http\Controllers;

use App\Models\LeaveBalance;
use App\Models\LeaveRequest;
use Illuminate\Http\Request;

class LeaveDashboardController extends Controller
{
    /**
     * Display listing of a leave for employee
     */
    public function index(){
        $user = auth()->user();

        if($user->role != 'Employee'){
            abort(403);
        }

        $balances = LeaveBalance::where('user_id', $user->id)->get();
        $requests = LeaveRequest::where('user_id', $user->id)->get();

        return view('leave.dashboard', compact('balances', 'requests'));
    }
}
