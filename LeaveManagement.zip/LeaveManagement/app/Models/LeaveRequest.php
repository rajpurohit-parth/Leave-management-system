<?php

namespace App\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class LeaveRequest extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'leave_requests';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<string>
     */
    protected $fillable = ['user_id', 'leave_type', 'start_date', 'end_date', 'reason', 'status'];

    /**
     *
     */
    public function user(){
        return $this->belongsTo(User::class);
    }
}
