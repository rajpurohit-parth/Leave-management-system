<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <h2>Leave Report</h2>

        <form method="GET" class="row align-item-end g-3">
            <div class="col-md-3">
                <label class="form-label">Leave Type</label>
                <select name="leave_type" id="" class="form-select">
                    <option value="">All Types</option>
                    <option value="Casual" <?php echo e(request('leave_type') == 'Casual' ? 'selectec' : ''); ?>>Casual</option>
                    <option value="Sick" <?php echo e(request('leave_type') == 'Sick' ? 'selectec' : ''); ?>>Sick</option>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label">From:</label>
                <input type="date" name="from" class="form-control" id="from" value="request('from')">
            </div>

            <div class="col-md-3">
                <label class="form-label">To:</label>
                <input type="date" name="to" class="form-control" id="to" value="request('to')">
            </div>

            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>

        <div class="card mt-5">

            <div class="card-body">
                <table class="table table-striped" id="leaveTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Leave Type</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($report): ?>
                            <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($r->user->name); ?></td>
                                    <td><?php echo e($r->leave_type); ?></td>
                                    <td><?php echo e($r->start_date); ?></td>
                                    <td><?php echo e($r->end_date); ?></td>
                                    <td><?php echo e($r->reason); ?></td>
                                    <td>
                                        <?php if($r->status == 'Approved'): ?>
                                            <span class="badge bg-success">Approved</span>
                                        <?php elseif($r->status == 'Rejected'): ?>
                                            <span class="badge bg-danger">Rejected</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Pending</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">No leave request found</td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#leaveTable').DataTable();
            });
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\LeaveManagement\resources\views/leave/report.blade.php ENDPATH**/ ?>