<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card">

            <div class="card-header">
                All Leave Requests
            </div>

            <div class="card-body">
                <table class="table table-striped" id="leaveTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Leave Type</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($requests): ?>
                            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($request->user->name); ?></td>
                                    <td><?php echo e($request->leave_type); ?></td>
                                    <td><?php echo e($request->start_date); ?></td>
                                    <td><?php echo e($request->end_date); ?></td>
                                    <td><?php echo e($request->reason); ?></td>
                                    <td>
                                        <?php if($request->status == 'Approved'): ?>
                                            <span class="badge bg-success">Approved</span>
                                        <?php elseif($request->status == 'Rejected'): ?>
                                            <span class="badge bg-danger">Rejected</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($request->status == 'Pending'): ?>
                                            <form
                                                action="<?php echo e(route('leave-requests.update', ['leave_request' => $request->id])); ?>"
                                                method="POST">
                                                <?php echo method_field('PUT'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-sm btn-success" name="status"
                                                    value="Approved">Approved</button>
                                                <button class="btn btn-sm btn-danger" name="status"
                                                    value="Rejected">Rejected</button>
                                            </form>
                                        <?php else: ?>
                                            <span>No Action</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">No leave request found</td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#leaveTable').DataTable();
            });
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\LeaveManagement\resources\views/leave/index.blade.php ENDPATH**/ ?>