@extends('layouts.app')

@section('content')
    <div class="container">

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        <h2>My Dashboard</h2>

        <div class="card">

            <div class="card-header">
                Leave Balance
            </div>

            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Leave Type</th>
                            <th>Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($balances as $balance)
                            <tr>
                                <td>{{ $balance->leave_type }}</td>
                                <td>{{ $balance->balance }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-3">
            <h4>My Leave Requests</h4>
            <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">+ Apply
                For Leave</button>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <table class="table table-striped" id="leaveTable">
                    <thead>
                        <tr>
                            <th>Leave Type</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($requests)
                            @foreach ($requests as $request)
                                <tr>
                                    <td>{{ $request->leave_type }}</td>
                                    <td>{{ $request->start_date }}</td>
                                    <td>{{ $request->end_date }}</td>
                                    <td>{{ $request->reason }}</td>
                                    <td>
                                        @if ($request->status == 'Approved')
                                            <span class="badge bg-success">Approved</span>
                                        @elseif($request->status == 'Rejected')
                                            <span class="badge bg-danger">Rejected</span>
                                        @else
                                            <span class="badge bg-warning">Pending</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="5" class="text-center">No leave request found</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form action="{{ route('leave-requests.store') }}" method="POST" id="leaveRequestForm">
                @csrf
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Apply For Leave</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="col-form-label">Leave Type</label>
                            <select name="leave_type" id="" class="form-select">
                                <option value="">Select Type</option>
                                <option value="Casual">Casual</option>
                                <option value="Sick">Sick</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="col-form-label">Start Date:</label>
                            <input type="date" name="start_date" class="form-control" id="start_date">
                        </div>
                        <div class="mb-3">
                            <label class="col-form-label">End Date:</label>
                            <input type="date" name="end_date" class="form-control" id="end_date">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Reason:</label>
                            <textarea class="form-control" id="message-text" name="reason"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#leaveTable').DataTable();

            $('#leaveRequestForm').validate({
                rules: {
                    leave_type: {
                        required: true,
                    },
                    start_date: {
                        required: true,
                    },
                    end_date: {
                        required: true,
                    },
                    reason: {
                        required: true,
                    },
                },
                messages: {
                    leave_type: "Please select a leave type",
                    start_date: "Please select start date",
                    end_date: "Please select a end date",
                    reason: "Please enter a reason",
                }
            });
        });

    </script>
@endsection
