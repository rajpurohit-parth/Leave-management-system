@extends('layouts.app')
@section('content')
    <div class="container mt-4">

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        <h2>Leave Report</h2>

        <form method="GET" class="row align-item-end g-3">
            <div class="col-md-3">
                <label class="form-label">Leave Type</label>
                <select name="leave_type" id="" class="form-select">
                    <option value="">All Types</option>
                    <option value="Casual" {{ request('leave_type') == 'Casual' ? 'selectec' : '' }}>Casual</option>
                    <option value="Sick" {{ request('leave_type') == 'Sick' ? 'selectec' : '' }}>Sick</option>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label">From:</label>
                <input type="date" name="from" class="form-control" id="from" value="request('from')">
            </div>

            <div class="col-md-3">
                <label class="form-label">To:</label>
                <input type="date" name="to" class="form-control" id="to" value="request('to')">
            </div>

            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>

        <div class="card mt-5">

            <div class="card-body">
                <table class="table table-striped" id="leaveTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Leave Type</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($report)
                            @foreach ($report as $r)
                                <tr>
                                    <td>{{ $r->user->name }}</td>
                                    <td>{{ $r->leave_type }}</td>
                                    <td>{{ $r->start_date }}</td>
                                    <td>{{ $r->end_date }}</td>
                                    <td>{{ $r->reason }}</td>
                                    <td>
                                        @if ($r->status == 'Approved')
                                            <span class="badge bg-success">Approved</span>
                                        @elseif($r->status == 'Rejected')
                                            <span class="badge bg-danger">Rejected</span>
                                        @else
                                            <span class="badge bg-warning">Pending</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="6" class="text-center">No leave request found</td>
                            </tr>
                        @endif

                    </tbody>
                </table>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#leaveTable').DataTable();
            });
        </script>
    </div>
@endsection
