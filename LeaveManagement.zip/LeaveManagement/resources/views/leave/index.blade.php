@extends('layouts.app')
@section('content')
    <div class="container mt-4">

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        <div class="card">

            <div class="card-header">
                All Leave Requests
            </div>

            <div class="card-body">
                <table class="table table-striped" id="leaveTable">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Leave Type</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($requests)
                            @foreach ($requests as $request)
                                <tr>
                                    <td>{{ $request->user->name }}</td>
                                    <td>{{ $request->leave_type }}</td>
                                    <td>{{ $request->start_date }}</td>
                                    <td>{{ $request->end_date }}</td>
                                    <td>{{ $request->reason }}</td>
                                    <td>
                                        @if ($request->status == 'Approved')
                                            <span class="badge bg-success">Approved</span>
                                        @elseif($request->status == 'Rejected')
                                            <span class="badge bg-danger">Rejected</span>
                                        @else
                                            <span class="badge bg-warning">Pending</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if ($request->status == 'Pending')
                                            <form
                                                action="{{ route('leave-requests.update', ['leave_request' => $request->id]) }}"
                                                method="POST">
                                                @method('PUT')
                                                @csrf
                                                <button class="btn btn-sm btn-success" name="status"
                                                    value="Approved">Approved</button>
                                                <button class="btn btn-sm btn-danger" name="status"
                                                    value="Rejected">Rejected</button>
                                            </form>
                                        @else
                                            <span>No Action</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="7" class="text-center">No leave request found</td>
                            </tr>
                        @endif

                    </tbody>
                </table>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#leaveTable').DataTable();
            });
        </script>
    </div>
@endsection
