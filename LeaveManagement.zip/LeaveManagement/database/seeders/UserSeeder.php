<?php

namespace Database\Seeders;

use Hash;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       $users = [
        ['name' => 'Akshay', 'email' => 'akshay@yopmail.com', 'password' => Hash::make('12345678'), 'role' => 'Employee'],
        ['name' => 'Sunil', 'email' => 'sunil@yopmail.com', 'password' => Hash::make('12345678'), 'role' => 'Employee'],
        ['name' => 'Vikash', 'email' => 'vikash@yopmail.com', 'password' => Hash::make('12345678'), 'role' => 'Manager'],
       ];

       User::insert($users);
    }
}
