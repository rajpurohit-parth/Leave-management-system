<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\LeaveBalance;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LeaveBalanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all();
        foreach ($users as $key => $user) {
            LeaveBalance::updateOrCreate(['user_id' => $user->id, 'leave_type' => 'casual'], ['balance' => 10]);
            LeaveBalance::updateOrCreate(['user_id' => $user->id, 'leave_type' => 'Sick'], ['balance' => 5]);
        }
    }
}
